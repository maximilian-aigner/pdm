coef.gcdclust <-
function(object, s = NULL, type = c("coefficients", 
    "nonzero"), ...) NextMethod("coef")

## ----eval=FALSE----------------------------------------------------------
#  grpreg(X, y, group, penalty="grLasso")

## ----eval=FALSE----------------------------------------------------------
#  grpreg(X, y, group, penalty="grMCP")

## ----eval=FALSE----------------------------------------------------------
#  grpreg(X, y, group, penalty="grSCAD")

## ----eval=FALSE----------------------------------------------------------
#  grpreg(X, y, group, penalty="gel")

## ----eval=FALSE----------------------------------------------------------
#  grpreg(X, y, group, penalty="cMCP")

## ----eval=FALSE----------------------------------------------------------
#  gBridge(X, y, group)

## ----eval=FALSE----------------------------------------------------------
#  grpreg(X, y, group, penalty="grLasso", alpha=0.75)


print.grpreg <- function(x) str(x)

show.grpreg <- function(x) str(x)
